# ESign adrian

Starter web pentru administrarea fișierelor IPA de pe iPhone: interfață dark, upload, bibliotecă și endpoint-uri pentru distribuție OTA.

## Ce este funcțional acum

- Interfață responsive pentru Safari/iPhone.
- Upload IPA prin formularul Files.
- Bibliotecă persistentă pe disc.
- Endpoint de descărcare IPA.
- Generare manifest OTA pentru aplicații marcate ca semnate și configurate.
- Endpoint-ul de semnare răspunde intenționat cu `501` până când este conectat un serviciu real de semnare.

## Cerințe

- Node.js 20+
- Un server HTTPS public pentru distribuția OTA reală.
- Spațiu de stocare suficient pentru IPA-uri.

## Pornire locală pentru testare

```bash
npm install
npm start
```

Deschide `http://localhost:3000`. Testarea locală verifică interfața și upload-ul; nu permite instalare OTA pe iPhone.

## Publicare

Publică proiectul pe un server Node.js cu HTTPS și setează:

```bash
PORT=3000
BASE_URL=https://domeniul-tau.example
```

Nu expune aplicația public fără autentificare, limite de upload, cote de stocare și protecție împotriva abuzului. Acest starter nu include încă autentificare sau administrare multi-utilizator.

## Instalare OTA pe iOS

Linkul de instalare Apple are forma:

```text
itms-services://?action=download-manifest&url=https://domeniul-tau.example/manifest/ID.plist
```

Manifestul este disponibil numai pentru înregistrări marcate ca `signed: true` și care au `bundleId`. Acest starter nu marchează automat IPA-urile ca semnate.

Pentru OTA sunt necesare:
- IPA semnat valid pentru dispozitiv/distribuție;
- manifest cu bundle identifier și versiune corecte;
- URL-uri HTTPS accesibile public;
- compatibilitate cu metoda de distribuție Apple folosită.

## Semnarea aplicațiilor

Semnarea reală nu poate fi făcută doar din browserul iPhone. Este necesar un serviciu backend pe un mediu macOS compatibil, cu:
- certificat Apple și cheia privată corespunzătoare (de exemplu, `.p12`);
- provisioning profile potrivit;
- verificarea bundle ID-ului și a entitlements;
- semnarea aplicației și a framework-urilor incluse;
- validarea rezultatului înainte de publicarea IPA-ului.

Nu încărca certificatul privat într-un server public fără autentificare, criptare, control de acces și stocare securizată. Un Apple ID gratuit are limitări de semnare și instalare; nu oferă distribuție OTA nelimitată.

## Fișiere

- `server.js` - API Express, upload și manifest OTA.
- `public/` - interfața web.
- `storage/ipas/` - fișiere IPA încărcate.
- `storage/apps.json` - catalogul aplicațiilor.
