const input = document.getElementById("ipaInput");
const statusEl = document.getElementById("uploadStatus");
const listEl = document.getElementById("appsList");
const toastEl = document.getElementById("toast");

function toast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  setTimeout(() => toastEl.classList.remove("show"), 3200);
}
function formatSize(bytes) {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
async function loadApps() {
  listEl.innerHTML = '<div class="empty card"><p>Se încarcă biblioteca…</p></div>';
  try {
    const response = await fetch("/api/apps");
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Nu s-a putut încărca biblioteca.");
    if (!data.apps.length) {
      listEl.innerHTML = '<div class="empty card"><div class="empty-icon">▣</div><strong>Biblioteca este goală</strong><p>Încarcă primul fișier IPA ca să apară aici.</p></div>';
      return;
    }
    listEl.innerHTML = data.apps.map(app => `
      <article class="app-row">
        <div class="app-icon">▣</div>
        <div class="app-meta"><strong>${escapeHtml(app.name)}</strong><small>${formatSize(app.size)} · ${new Date(app.uploadedAt).toLocaleDateString("ro-RO")}</small></div>
        <span class="pill">${app.signed ? "SIGNED" : "NESEMNAT"}</span>
      </article>`).join("");
  } catch (error) {
    listEl.innerHTML = `<div class="empty card"><strong>Eroare</strong><p>${escapeHtml(error.message)}</p></div>`;
  }
}
input.addEventListener("change", async () => {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!file.name.toLowerCase().endsWith(".ipa")) {
    toast("Alege un fișier cu extensia .ipa.");
    input.value = "";
    return;
  }
  const form = new FormData();
  form.append("ipa", file);
  statusEl.textContent = `Se încarcă ${file.name}…`;
  try {
    const response = await fetch("/api/upload", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Încărcarea a eșuat.");
    statusEl.textContent = `${file.name} a fost încărcat. Pentru instalare este necesară semnarea validă și configurarea HTTPS.`;
    toast("IPA încărcat în bibliotecă.");
    await loadApps();
  } catch (error) {
    statusEl.textContent = error.message;
    toast(error.message);
  } finally {
    input.value = "";
  }
});
document.getElementById("refreshBtn").addEventListener("click", loadApps);
document.getElementById("certInfoBtn").addEventListener("click", () => {
  toast("Ai nevoie de un certificat Apple valid și un provisioning profile. Semnarea nu este activată încă.");
});
loadApps();
