"use strict";

const express = require("express");
const helmet = require("helmet");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const DATA_DIR = path.join(__dirname, "storage");
const IPA_DIR = path.join(DATA_DIR, "ipas");
const DB_FILE = path.join(DATA_DIR, "apps.json");

fs.mkdirSync(IPA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]");

app.use(helmet({
  // OTA installation requires a valid HTTPS origin in production.
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: null
    }
  }
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function readApps() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return []; }
}
function writeApps(apps) {
  fs.writeFileSync(DB_FILE, JSON.stringify(apps, null, 2));
}
function safeName(name) {
  return String(name || "application").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, IPA_DIR),
    filename: (_req, file, cb) => {
      const id = crypto.randomUUID();
      cb(null, `${id}-${safeName(file.originalname)}`);
    }
  }),
  limits: { fileSize: 1024 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (path.extname(file.originalname).toLowerCase() !== ".ipa") {
      return cb(new Error("Alege un fișier .ipa."));
    }
    cb(null, true);
  }
});

app.get("/api/apps", (_req, res) => {
  const apps = readApps().map(({ file, ...publicApp }) => publicApp);
  res.json({ apps });
});

app.post("/api/upload", upload.single("ipa"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Nu a fost primit niciun fișier IPA." });

  const appRecord = {
    id: crypto.randomUUID(),
    name: path.basename(req.file.originalname, ".ipa"),
    file: req.file.filename,
    size: req.file.size,
    uploadedAt: new Date().toISOString(),
    status: "uploaded",
    signed: false,
    installUrl: null
  };

  const apps = readApps();
  apps.unshift(appRecord);
  writeApps(apps);
  const { file, ...publicApp } = appRecord;
  res.status(201).json({ app: publicApp, message: "IPA încărcat. Pentru instalare OTA, fișierul trebuie să fie semnat și serverul trebuie să folosească HTTPS." });
});

// Download endpoint for an already signed IPA. Keep the file URL private in a real deployment.
app.get("/ipa/:id", (req, res) => {
  const record = readApps().find(x => x.id === req.params.id);
  if (!record) return res.status(404).send("Aplicația nu există.");
  res.type("application/octet-stream");
  res.download(path.join(IPA_DIR, record.file), `${safeName(record.name)}.ipa`);
});

// Apple OTA manifest. Works only for a valid, signed IPA with a matching bundle identifier.
app.get("/manifest/:id.plist", (req, res) => {
  const record = readApps().find(x => x.id === req.params.id);
  if (!record || !record.signed || !record.bundleId) {
    return res.status(409).send("Aplicația nu este semnată/configurată pentru instalare OTA.");
  }

  const ipaUrl = `${BASE_URL}/ipa/${record.id}`;
  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>items</key><array><dict><key>assets</key><array><dict>
<key>kind</key><string>software-package</string>
<key>url</key><string>${ipaUrl}</string>
</dict></array><key>metadata</key><dict>
<key>bundle-identifier</key><string>${escapeXml(record.bundleId)}</string>
<key>bundle-version</key><string>${escapeXml(record.version || "1.0")}</string>
<key>kind</key><string>software</string>
<key>title</key><string>${escapeXml(record.name)}</string>
</dict></dict></array></dict></plist>`;
  res.type("application/xml").send(plist);
});

function escapeXml(value) {
  return String(value).replace(/[<>&'"]/g, c => ({
    "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
  }[c]));
}

// Deliberately does not fake signing. A production signer must be configured on a
// trusted macOS signing host with a valid certificate/private key and provisioning profile.
app.post("/api/sign/:id", (_req, res) => {
  res.status(501).json({
    error: "Semnarea nu este configurată pe acest server.",
    details: "Adaugă un serviciu de semnare pe un Mac/server macOS, cu certificat Apple valid (.p12) și provisioning profile. Nu încărca certificate private pe un server public fără protecție."
  });
});

app.use((err, _req, res, _next) => {
  const status = err instanceof multer.MulterError ? 400 : 400;
  res.status(status).json({ error: err.message || "Eroare la încărcare." });
});

app.listen(PORT, () => {
  console.log(`ESign adrian running at ${BASE_URL}`);
});
